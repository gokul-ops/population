let Container = document.createElement("div");
Container.className = "container";
document.body.appendChild(Container);

let webInstructions = document.createElement("p");
webInstructions.className = "web-instructions";
webInstructions.innerText = `Click the 'Fetch Data' button to access all the breweries.`                      
Container.appendChild(webInstructions);

let fetchDataBtn = document.createElement("button");
fetchDataBtn.innerText   = "Fetch data";
fetchDataBtn.className = "fetchDataBtn";
Container.appendChild(fetchDataBtn);

let searchArea = document.createElement("div");
searchArea.className = "searchArea";
Container.appendChild(searchArea);

let searchInput = document.createElement("input");
searchInput.className = "searchInput";
searchInput.placeholder = "Search here...";
searchArea.appendChild(searchInput);


const result = document.createElement("div");
result.className = "result";
Container.appendChild(result);

fetchDataBtn.addEventListener('click', async() => {
    try{
        const response = await fetch("https://api.openbrewerydb.org/breweries?page=1&per_page=50");
        const jsonData = await response.json();
        console.log(jsonData);

        //iterate through json data to create cards of data
        for(let i = 0; i < jsonData.length; i++) {
            let brewData = document.createElement("div"); 
            brewData.innerHTML = `
            <div class = "card">
                <div class = "card-body">
                    <h3 class = "card-title">${jsonData[i].name}</h5>
                    <h6 class = "card-text">population: ${jsonData[i].population}<br><br>
                    country: ${jsonData[i].country}<br><br>
                    religon:${jsonData[i].street}, ${jsonData[i].city}, ${jsonData[i].state}, ${jsonData[i].country},<br>
                    sub_religon:${jsonData[i].sub_religon}<br><br>
                    <a href = "${jsonData[i].website_url}" target = "_blank" class = "breweryWebsite">${jsonData[i].website_url}</a>
                    
            `
            result.appendChild(brewData);
            
        }
        
    }
    catch(error){
        result.innerHTML = error;
    }
});

 
searchBtn.addEventListener("click", async() => {
    let searchTerm = document.querySelector(".searchInput").value;
    
    const response = await fetch("https://api.openbrewerydb.org/breweries?page=1&per_page=50");
    const jsonData = await response.json();
    

    let filtered_arr = [];
    
    for(let i = 0; i < jsonData.length; i++){
        if((jsonData[i].name.toLowerCase()).includes(searchTerm.toLowerCase())){
            filtered_arr.push(jsonData[i]);
        }
    }
    
    const emptyResult = document.querySelector(".result");
    emptyResult.innerHTML = "";
    

    for(let i = 0; i < filtered_arr.length; i++) {
        let brewData = document.createElement("div"); 
        brewData.innerHTML = `
        <div class = "card">
            <div class = "card-body">
                <h3 class = "card-title">${filtered_arr[i].name}</h5>
                <h6 class = "card-text">Brewery Type: ${filtered_arr[i].brewery_type}<br><br>
                country: ${filtered_arr[i].country}<br><br>
                religon:${filtered_arr[i].religon}, ${filtered_arr[i].city}, ${filtered_arr[i].state}, ${filtered_arr[i].country}<br><br>
                sub_religon:${filtered_arr[i].sub_religon} </h6>
                <a href = "${filtered_arr[i].website_url}" target = "_blank" class = "breweryWebsite">${filtered_arr[i].website_url}</a>
        `
        result.appendChild(brewData);
        
    }
    
    
   
});
